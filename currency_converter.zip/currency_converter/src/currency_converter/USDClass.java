package currency_converter;

public class USDClass {
float usdQty;

public USDClass(float usdQty) {
	super();
	this.usdQty = usdQty;
}

}
