package currency_converter;

import java.util.Scanner;

public class MainClass {
	public static void main(String arg[]) {
		Scanner sc=new Scanner(System.in);
		Scanner sc1=new Scanner(System.in);
		float quantity;
		String dest;
		System.out.println("Enter the quantity of USD: ");
		quantity=sc.nextFloat();
		System.out.println("Enter the destination currency to convert : ");
		dest=sc1.nextLine();
		ConverterClass convertCurrency = new ConverterClass(quantity,dest);
		//ConverterClass convertCurrency = new ConverterClass((float) 10.0,"AD");
		if(validate(quantity,dest))
			convertCurrency.display();
		else
			System.out.println("Unable to convert the given input");

	}
	static boolean validate(float usdQty, String destination) {
		
		if(usdQty==(float)usdQty&&usdQty>0 && (destination.equals("EUR")||destination.equals("INR")||destination.equals("MYR")||destination.equals("SGD")||destination.equals("GBP")||destination.equals("CAD")))                                                           
			return true;
		return false;
	}

}
