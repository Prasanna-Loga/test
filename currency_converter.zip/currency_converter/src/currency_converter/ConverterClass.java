package currency_converter;

public class ConverterClass {
String destCurrency;
USDClass s;
public ConverterClass(float usdQty,String destCurrency) {
	super();
	s=new USDClass(usdQty);
	this.destCurrency = destCurrency;
}

public float convertCurrency() {
	if(destCurrency.equals("EUR"))
	{
		return (float) (s.usdQty*0.81);
	}
	if(destCurrency.equals("INR"))
	{
		return (float) (s.usdQty*64.31);
	}
	if(destCurrency.equals("MYR"))
	{
		return (float) (s.usdQty*3.95);
	}
	if(destCurrency.equals("SGD"))
	{
		return (float) (s.usdQty*1.32);
	}
	if(destCurrency.equals("GBP"))
	{
		return (float) (s.usdQty*0.72);
	}
	if(destCurrency.equals("CAD"))
	{
		return (float) (s.usdQty*1.26);
	}
	return 0;
	
}
public void display() {
	System.out.println("The "+destCurrency+" amount equivalent to "+s.usdQty+" USD is : "+convertCurrency());
}


}
